package com.example.myapplication21;

public interface DatosContador {

    public void enviarDatosContador(int dato);


}
